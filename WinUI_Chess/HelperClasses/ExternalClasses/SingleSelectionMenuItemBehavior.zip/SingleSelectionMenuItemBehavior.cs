﻿// 
// Marcel's Blog: http://dutchmarcel.wordpress.com/
// Source: https://onedrive.live.com/?cid=027cdb908d14e584&id=27CDB908D14E584%21918
// 
namespace DutchMarcel.WPF
{
    using System.Windows;
    using System.Windows.Controls;

    public static class SingleSelectionMenuBehavior
    {
        #region IsSingleSelection
        /// <summary>
        /// IsSingleSelection Attached Dependency Property
        /// </summary>
        public static readonly DependencyProperty IsSingleSelectionProperty =
            DependencyProperty.RegisterAttached("IsSingleSelection", typeof(bool), typeof(SingleSelectionMenuBehavior),
                new FrameworkPropertyMetadata((bool)false,
                    new PropertyChangedCallback(OnIsSingleSelectionChanged)));

        /// <summary>
        /// Gets the IsSingleSelection property.
        /// </summary>
        public static bool GetIsSingleSelection(DependencyObject d)
        {
            return (bool)d.GetValue(IsSingleSelectionProperty);
        }

        /// <summary>
        /// Sets the IsSingleSelection property.
        /// </summary>
        public static void SetIsSingleSelection(DependencyObject d, bool value)
        {
            d.SetValue(IsSingleSelectionProperty, value);
        }
        #endregion

        /// <summary>
        /// Handles changes to the IsSingleSelection property.
        /// </summary>
        private static void OnIsSingleSelectionChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            MenuItem item = d as MenuItem;
            if (item == null)
                return;
            if (e.NewValue is bool == false)
                return;

            if ((bool)e.NewValue)
            {
                item.IsHitTestVisible = !item.IsChecked;
                item.Checked += OnItemChecked;
            }
            else
            {
                item.Checked -= OnItemChecked;
                item.IsHitTestVisible = true;
            }
        }

        private static void OnItemChecked(object sender, RoutedEventArgs e)
        {
            MenuItem item = sender as MenuItem;
            if (item != null)
            {
                // disable checked item to prevent unchecking
                item.IsHitTestVisible = false;

                ItemsControl ic = ItemsControl.ItemsControlFromItemContainer(item);
                foreach (object menuitem in ic.Items)
                {
                    MenuItem container = ic.ItemContainerGenerator.ContainerFromItem(menuitem) as MenuItem;
                    if (container != item)
                    {
                        container.IsChecked = false;
                        container.IsHitTestVisible = true;
                    }
                }
            }
        }
    }
}
